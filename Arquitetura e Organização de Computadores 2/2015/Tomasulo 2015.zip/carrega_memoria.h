#ifndef Carregar_
#define Carregar_

int carregar_programa();
void carregar_janela();
void carregarAddressUnit();
void carregarReservationStation();
void processarMemoryUnit();
void carregarWindow();


extern int *inst;
extern int *dest;
extern int *src1;
extern int *src2;

#endif
