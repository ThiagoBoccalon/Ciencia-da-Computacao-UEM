#ifndef Util_
#define Util_

int* fetch_instructionOPCode(char* inst);
int* fetch_register(char* reg);
int* fetch_Tag(int* reg);
char* fetch_Register(int* reg);

#endif
